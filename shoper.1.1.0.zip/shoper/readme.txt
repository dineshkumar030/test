=== Shoper ===
Contributors: aThemeArt
Donate link:  https://athemeart.com/downloads/wordpress-shop-theme-freefree-wordpress-gaming-themes/
Requires at least: 5.0
Tested up to: 5.5.0
Requires PHP: 7.0
License: GPLv3 or later 
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Shoper theme is a free, beautiful, trendy, and modern WordPress store theme. And to clarify, it's built for multipurpose shops, especially a fashion store, supermarket, electronics, computer parts, beauty, health, jewelry, or any relevant WordPress shop. But, you can also use it for a personal blog, affiliate product review any relevant WordPress shop theme. So, what do you think? Do you need a WordPress shop theme free, which you can make your website shoppable? Ok, before adopting any decision, we love to give you furthermore information about the Shopper theme. Firstly, it provides several different shop front layouts, manageable product columns, and product filters. It also has exceptional typography and color schemes that make your products shoppable. Also, it includes Live Customizer for easy manages your all options. Besides, it's accurately working with Elementor, Beaver Builder, Brizy, Visual Composer, Divi, SiteOrigin, etc. Plus, you have the control to customize the settings for Desktop, Tablet, and Mobiles so, your site looks gorgeous on every device. And the most important thing is it's translation-ready, retina-ready, and WooCommerce compatible. Therefore, you can call this Shoper theme a WooCommerce storefront. Also, this WordPress WooCommerce theme wrap with an extensible codebase. That is the best thing for developers because they can customize and extend very comfortably.



== Copyright ==
Shoper WordPress Theme, Copyright (C) 2020 aThemeArt.com
Shoper is distributed under the terms of the GNU GPL

== Frequently Asked Questions == 

1. How to add screenshot box .
	please use elementor page builder and theme recommended plugins, you will find lot of widget to create as our screenshot.

   	
== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==

Underscores:
Author: 2012-2015 Automattic
Source: http://underscores.me
License: GPLv2 or later

Bootstrap:
Source: https://github.com/twbs/bootstrap/tree/v4.0.0
License: MIT License

Customizer:
Author: https://github.com/justintadlock
Source: https://github.com/justintadlock/trt-customizer-pro
License: GNU GPL

Owl Carousel 2:
Author: David Deutsch
Source: https://github.com/OwlCarousel2/OwlCarousel2
License: [MIT License.]

Sticky sidebar :
Author:  Anthony Garand    
Source: https://github.com/garand/sticky
License: MIT License

Tgmpluginactivation:
Source: http://tgmpluginactivation.com/
License: GPL-2.0 or later license.

icofont:
Source: https://icofont.com/license
License: MIT License.

jquery.customSelect:
Author:  Adam Coulombe    
Source: http://adam.co/lab/jquery/customselect/
License: GPL2

Scrollbar :
Author:   abouolia    
Source: https://github.com/abouolia/sticky-sidebar/
License: MIT License

== Image Used ==

https://pxhere.com/en/photo/1451201
https://pxhere.com/en/photo/1349204
All are Licensed under CC0

Name : WooCommerce demo data on screenshot 
License:   GPLv3

Name : screenshot.png logo, 404.png 
License:  Self created by athemeart.com 


== Screenshots ==

1. screenshot.png

== Upgrade Notice  ==

= 1.0.9 =
* theme review team feedbakc fixing

= 1.0.8 =
* theme review team feedbakc fixing

= 1.0.7 =
* Fixing result-count.php esc issue

= 1.0.6 =
* initial released

